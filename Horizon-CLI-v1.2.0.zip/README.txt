HORIZON CLI  v1.2.0
===================
Chat with the best free AI models from your terminal. Horizon ranks every
free model across several providers, picks the best one, and switches
automatically when one hits a rate limit, while keeping your conversation.


WHICH FILE DO I NEED?
---------------------
  Windows (most PCs) ........ horizon-windows-amd64.exe
  Windows on ARM ............ horizon-windows-arm64.exe
  Mac (Intel or Apple chip) . horizon-macos


START IT
--------
Windows
  1. Double-click the .exe.
  2. If you see "Windows protected your PC", click "More info", then "Run anyway".
     (The app isn't code-signed, so Windows doesn't recognize it yet.)
  3. Say yes when it offers to install. After that, open any terminal and type:  hz

Mac
  1. Open Terminal and run these two lines (drag the file into Terminal to fill in its path):
       chmod +x ~/Downloads/horizon-macos
       xattr -d com.apple.quarantine ~/Downloads/horizon-macos
  2. Run it:  ~/Downloads/horizon-macos
  3. Say yes when it offers to install. Then open a new Terminal window and type:  hz

The first run walks you through adding API keys.


API KEYS (free, about a minute each, add at least one)
------------------------------------------------------
  Groq ............. https://console.groq.com/keys           very fast, good daily limits
  NVIDIA NIM ....... https://build.nvidia.com/settings/api-keys   big models, ~40 req/min, no daily cap
  OpenRouter ....... https://openrouter.ai/settings/keys     many models, 50 free req/day
  Google AI Studio . https://aistudio.google.com/apikey      Gemini, huge context
  Cerebras ......... https://cloud.cerebras.ai/platform      fastest, small context
  Mistral .......... https://console.mistral.ai/api-keys     needs phone verification

More keys means more models to fall back on. Add or change them anytime:  hz setup
Keys are stored in your system keychain (Windows Credential Manager / macOS
Keychain) on your own computer and are only ever sent to the provider they
belong to.


COMMANDS
--------
  hz                         start chatting
  hz chat --resume           continue your last chat
  hz ask "question"          one quick answer (you can also pipe text in)
  hz rank --probe            test and rank every free model
  hz models                  list every free model found
  hz prefer quality          rank by quality, speed, coding or balanced
  hz setup                   add or change API keys
  hz sessions                saved chats
  hz help                    everything else

Inside a chat:
  /model                     which model is answering
  /switch                    move to the next best model now
  /use <name>                prefer a model  (/use auto to go back)
  /pin <text>                a fact every model always sees in this chat
  /pin! <text>               same, but for every chat
  /onswitch <text>           the message sent to a model when it takes over
  /onswitch-for <pattern> = <text>   a takeover message just for certain models
  /modelprompt <pattern> = <text>    always-on instructions for certain models
                                     e.g.  /modelprompt *deepseek* = Keep thinking short.
  /report [note]             the takeover message didn't work on this model
  /handover visible|silent   show or hide the takeover exchange
  /prefer <mode>             quality, speed, coding or balanced (saved)
  /context                   how much of the conversation is kept
  /help                      all chat commands
  Ctrl+C stops a reply. Ctrl+D or /exit quits.


HOW SWITCHING WORKS
-------------------
When a model fails (rate limit, quota used up, error, timeout), Horizon tries
the next best one and resends your message, so you rarely see an error.
On each switch it sends the new model a takeover message and shows you the
model's reply:

  ◉ crossed horizon → nim/qwen3-235b  (groq/llama-3.3-70b: 429 rate limit)
    ┌ handover → nim/qwen3-235b
    │ sent:  You are taking over an ongoing conversation...
    │ reply: Caught up: we're debugging the login script.
    └ didn't land? /report

If a model ignores it, type /report. That model then gets a stronger
takeover message from then on, and you can give it its own with /onswitch-for.
Visible takeovers use one extra request per switch. /handover silent turns that off.

When a model has a smaller context window, older messages are compressed into
a summary so nothing important is lost. Pins are never compressed.


FILES
-----
Settings, chats and usage counters live in:
  Windows:  %AppData%\horizon-cli\
  Mac:      ~/Library/Application Support/horizon-cli/
Edit config.toml there (or run  hz config edit) for prompts, pins, ranking
weights and per-provider limits. Delete it to reset to defaults.

Update:     download the new version and run it. It offers to replace your
            installed hz (keys and chats are kept).
Uninstall:  hz uninstall         removes the program, keeps keys and chats
            hz uninstall --all   removes everything (program, PATH entry,
                                 keys, chats, settings), after you type yes
